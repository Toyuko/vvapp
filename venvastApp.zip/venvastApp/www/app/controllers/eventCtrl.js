app.controller('eventCtrl', function($scope, $ionicScrollDelegate, $state, ionicDatePicker, $ionicModal) {
        $scope.pieces = ['RESTRAUNTS', 'LIFESTYLE', 'CLUBS', 'NETWORKING', 'OTHER', 'VENVAST', 'SUPERFAST'];
        $scope.eventnumber = ['X Events'];
        $scope.title = 'LIVE';

        $scope.SubTab = false;


});